import { PanelizationCandidate, CandidateScore, StrategicContext } from './types';
import { Opening } from '../../core/types';
import { getPanelizationRules } from '../rules/panelization';
import { round } from '../../utils/math';

export function scoreCandidate(candidate: PanelizationCandidate, context: StrategicContext, openings: Opening[]): void {
  const { openingClearance, maxWidth } = getPanelizationRules();
  
  const components = {
    panelCount: calculatePanelCountScore(candidate),
    widthBalance: calculateBalanceScore(candidate),
    openingSafety: calculateSafetyScore(candidate, openings, openingClearance),
    constructability: calculateComplexityScore(candidate, maxWidth),
    continuity: 50 // Baseline for Phase 1 (local optimization)
  };

  const penalties: string[] = [];
  const bonuses: string[] = [];
  
  // Apply Penalties/Bonuses
  if (candidate.splits.some(w => w < 2.2)) {
      penalties.push('PENALTY_NEAR_MIN_WIDTH');
  }
  if (candidate.panelCount <= 2) {
      bonuses.push('BONUS_SIMPLE_WALL');
  }

  // Calculate total (Weighted Average)
  const total = round(
    (components.panelCount * 0.30) +
    (components.widthBalance * 0.25) +
    (components.openingSafety * 0.20) +
    (components.constructability * 0.15) +
    (components.continuity * 0.10)
  );

  candidate.score = {
    total,
    components,
    penalties,
    bonuses
  };
}

function calculatePanelCountScore(candidate: PanelizationCandidate): number {
  // Lower panel count is better. Baseline 100 for 1 panel, -10 per extra panel.
  return Math.max(0, 100 - (candidate.panelCount - 1) * 10);
}

function calculateBalanceScore(candidate: PanelizationCandidate): number {
  if (candidate.panelCount <= 1) return 100;
  
  const avg = candidate.splits.reduce((a, b) => a + b, 0) / candidate.panelCount;
  const variance = candidate.splits.reduce((a, b) => a + Math.pow(b - avg, 2), 0) / candidate.panelCount;
  const stdDev = Math.sqrt(variance);
  
  // stdDev of 0 = 100 points. stdDev of 0.5 = 50 points.
  return Math.max(0, 100 - round(stdDev * 100));
}

function calculateSafetyScore(candidate: PanelizationCandidate, openings: Opening[], clearance: number): number {
  if (openings.length === 0) return 100;
  
  let minSafeDistance = Infinity;
  let currentOffset = 0;
  
  for (let i = 0; i < candidate.splits.length - 1; i++) {
    const jointPos = currentOffset + candidate.splits[i];
    openings.forEach(op => {
      const distStart = Math.abs(jointPos - op.position);
      const distEnd = Math.abs(jointPos - (op.position + op.width));
      minSafeDistance = Math.min(minSafeDistance, distStart, distEnd);
    });
    currentOffset += candidate.splits[i];
  }

  // If minSafeDistance is clearance + 0.5m, it's very safe (100).
  // If it's exactly clearance, it's baseline safe (50).
  const score = round((minSafeDistance / (clearance + 0.5)) * 100);
  return Math.min(100, Math.max(0, score));
}

function calculateComplexityScore(candidate: PanelizationCandidate, maxWidth: number): number {
  // Prefer standard widths (e.g. multiples of 1.2m or just the max width)
  const deviationsFromMax = candidate.splits.reduce((acc, w) => acc + (maxWidth - w), 0);
  return Math.max(0, 100 - round(deviationsFromMax * 10));
}
