import { Opening, Wall } from '../../core/types';
import { PanelizationCandidate, StrategicContext } from './types';
import { generateCandidates } from './candidate-generator';
import { validateCandidate } from './candidate-validator';
import { scoreCandidate } from './candidate-scorer';
import { logger } from '../../utils/logger';

export class StrategicArbiter {
  static resolveBestPlan(wallId: string, wallLength: number, openings: Opening[], context: StrategicContext): PanelizationCandidate {
    logger.log('STRATEGIC_ARBITRATION_STARTED', wallId, `Generating and evaluating candidates for ${wallId}`);

    // 1. Generate Candidates
    const candidates = generateCandidates(wallId, wallLength, openings);
    logger.log('CANDIDATES_GENERATED', wallId, `Generated ${candidates.length} hypotheses`);

    // 2. Validate (Hard Veto)
    const validCandidates = candidates.filter(c => {
      validateCandidate(c, wallLength, openings);
      if (!c.valid) {
        logger.log('CANDIDATE_VETOED', c.id, `Rejection reason: ${c.rejectionReason}`, { strategy: c.strategy });
      }
      return c.valid;
    });

    if (validCandidates.length === 0) {
      logger.log('STRATEGIC_ARBITRATION_FAILED', wallId, '100% of candidates vetoed. No valid plan possible.');
      throw new Error(`CRITICAL_STRATEGIC_FAILURE: No valid panelization plan found for wall ${wallId} using any available strategy.`);
    }

    // 3. Score
    validCandidates.forEach(c => scoreCandidate(c, context, openings));

    // 4. Select Winner (with Deterministic Tie-Breakers)
    const winner = validCandidates.sort((a, b) => {
      // Primary: Total Score
      const scoreDiff = b.score!.total - a.score!.total;
      if (Math.abs(scoreDiff) > 0.001) return scoreDiff;

      // Tie-breaker 1: Fewer Panels
      const panelDiff = a.panelCount - b.panelCount;
      if (panelDiff !== 0) return panelDiff;

      // Tie-breaker 2: Opening Safety
      const safetyDiff = b.score!.components.openingSafety - a.score!.components.openingSafety;
      if (Math.abs(safetyDiff) > 0.001) return safetyDiff;

      // Tie-breaker 3: Balance
      const balanceDiff = b.score!.components.widthBalance - a.score!.components.widthBalance;
      if (Math.abs(balanceDiff) > 0.001) return balanceDiff;

      // Final: Lexicographical by strategy name (pure determinism)
      return a.strategy.localeCompare(b.strategy);
    })[0];

    logger.log('STRATEGIC_WINNER_SELECTED', wallId, `Winner: ${winner.strategy} with score ${winner.score!.total}`, {
        winnerId: winner.id,
        panelCount: winner.panelCount,
        components: winner.score!.components
    });

    return winner;
  }
}
