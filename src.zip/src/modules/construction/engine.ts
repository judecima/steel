import { Wall, Panel, HouseModel } from '../../core/types';
import { logger } from '../../utils/logger';
import { splitWallIntoPanels } from './panelization';
import { applyStudLayout } from './stud-layout';
import { applyOpeningReinforcements } from './openings';
import { applyJunctions } from './junctions';

export function panelizeHouse(house: HouseModel): Panel[] {
  const allPanels: Panel[] = [];

  house.walls.forEach((wall, index) => {
    logger.log('PROCESSING_WALL', wall.id, `Processing wall ${index + 1}/${house.walls.length}`);
    
    // 1. Split wall into panels
    const panels = splitWallIntoPanels(wall);

    // 2. Process each panel
    panels.forEach((panel, pIndex) => {
      // 2.1 Basic stud layout
      applyStudLayout(panel, wall.role);

      // 2.2 Opening reinforcements
      applyOpeningReinforcements(panel);

      // 2.3 Junctions / Corners
      const isFirstPanel = pIndex === 0;
      const isLastPanel = pIndex === panels.length - 1;
      applyJunctions(panel, wall.role, isFirstPanel, isLastPanel);

      allPanels.push(panel);
    });
  });

  logger.log('HOUSE_PANELIZED', 'house', 'All walls processed', { totalPanels: allPanels.length });
  
  return allPanels;
}
